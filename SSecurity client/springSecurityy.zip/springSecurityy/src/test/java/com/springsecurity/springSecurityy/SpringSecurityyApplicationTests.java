package com.springsecurity.springSecurityy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringSecurityyApplicationTests {

	@Test
	void contextLoads() {
	}

}
